package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.DriverEntity;
import com.example.demo.entities.DummyDriverRegistration;
import com.example.demo.entities.RoleEntity;
import com.example.demo.entities.UserEntity;
import com.example.demo.services.DriverService;
import com.example.demo.services.RoleService;
import com.example.demo.services.UserService;

@RestController
public class DriverController {
    @Autowired
    DriverService dservice;
    
    @Autowired
	UserService userservice;

	@Autowired
	RoleService rservice;
    
    @PostMapping("/saveDriver")
	public DriverEntity saveDriver(@RequestBody DriverEntity d)
	{
		return dservice.saveDriver(d);
	}
    
    @GetMapping("/getAllDriver")
	public List<DriverEntity> getAllDriver()
	{
		return dservice.getAllDriver();
	}
   
	
	@PostMapping("/registerDriver")
	public DriverEntity registerDoctor(@RequestBody DummyDriverRegistration ddr) {
		RoleEntity r = rservice.getRole(2);

		UserEntity ue = new UserEntity(ddr.getPassword(), ddr.getUsername(), r, 0);
		userservice.save(ue);
		DriverEntity dr = new DriverEntity(ue,ddr.getFname(),ddr.getLname(),ddr.getContact(),ddr.getEmail(),ddr.getAddress(),ddr.getRating(),ddr.getEmergency_contact(),ddr.getMake(),ddr.getModel(),ddr.getRegistration_no(),ddr.getLicence_no(),ddr.getNo_plate());
		ddr.setUuser_id(ue.getUser_id());
		return dservice.saveDriver(dr);
	}
	
}
