package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.DummyUserEntity;
import com.example.demo.entities.UserEntity;
import com.example.demo.services.UserLoginService;


@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class UserLoginController {

	@Autowired   
	UserLoginService lservice;
	
	@PostMapping("/verifyLogin")
	public UserEntity  verifyLogin ( @RequestBody DummyUserEntity loginData) {
		
			return lservice.getLoginDetails(loginData.getUsername(), loginData.getPassword());
		
	}
	
	
}
