package com.example.demo.entities;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Component
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "users")
public class UserEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int user_id;
	@Column
	String username;
	@Column
	String password;
	@ManyToOne
	@JoinColumn(name = "role_id")
	RoleEntity role_id;
	
	private int status;

	public UserEntity(String username, String password, RoleEntity role_id,int status) {
		super();
		this.username = username;
		this.password = password;
		this.role_id = role_id;
		this.status=status;
		
	}
}
