package com.example.demo.entities;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;




@Entity
@Table(name = "passengers")
@Getter
@Setter
@Component
@AllArgsConstructor
@NoArgsConstructor
public class PassengerEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int passenger_id;
    
    //@JsonIgnoreProperties("passengers")
    @OneToOne
    @JoinColumn(name="user_id")
    private UserEntity user_id;
    
    @Column(name = "fname")
    private String fname;

    @Column(name = "lname")
    private String lname;

    @Column(name = "contact")
    private String contact;

    @Column(name = "email")
    private String email;

    @Column(name = "address")
    private String address;

    @Column(name = "rating")
    private double rating;

    @Column(name = "emergency_contact")
    private String emergency_contact;

   
    
	public PassengerEntity(UserEntity user, String fname, String lname, String contact, String email, String address,
			String emergency_contact) {
		super();
		this.user_id = user;
		this.fname = fname;
		this.lname = lname;
		this.contact = contact;
		this.email = email;
		this.address = address;
		this.emergency_contact = emergency_contact;
	}

	public PassengerEntity(String fname2, String lname2, String email2, String contact2, String emergency_contact, String address2,
			UserEntity user) {
		this.user_id = user;
		this.fname = fname2;
		this.lname = lname2;
		this.contact = contact2;
		this.email = email2;
		this.address = address2;
		this.emergency_contact = emergency_contact;
	}
}

