package com.example.demo.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Table(name = "drivers")
public class DriverEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int driver_id;

	//@JsonIgnoreProperties("drivers")
	@OneToOne
	@JoinColumn(name = "user_id")
	private UserEntity user_id;


	@Column(name = "fname")
	private String fname;

	@Column(name = "lname")
	private String lname;

	@Column(name = "contact")
	private String contact;

	@Column(name = "email")
	private String email;

	@Column(name = "address")
	private String address;

	@Column(name = "rating")
	private double rating;

	@Column(name = "emergency_contact")
	private String emergency_contact;
	
	@Column(name = "licence_no")
	private String licence_no;
	
	@Column
	private String make;
	
	@Column
	private String colour;
	@Column
	private String registration_no;
	@Column
	private String no_plate;
	public DriverEntity(UserEntity user_id, String fname, String lname, String contact, String email, String address,
			double rating, String emergency_contact, String licence_no, String make, String colour,
			String registration_no, String no_plate) {
		super();
		this.user_id = user_id;
		this.fname = fname;
		this.lname = lname;
		this.contact = contact;
		this.email = email;
		this.address = address;
		this.rating = rating;
		this.emergency_contact = emergency_contact;
		this.licence_no = licence_no;
		this.make = make;
		this.colour = colour;
		this.registration_no = registration_no;
		this.no_plate = no_plate;
	}
	public int getDriver_id() {
		return driver_id;
	}
	public void setDriver_id(int driver_id) {
		this.driver_id = driver_id;
	}
	public UserEntity getUser_id() {
		return user_id;
	}
	public void setUser_id(UserEntity user_id) {
		this.user_id = user_id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getEmergency_contact() {
		return emergency_contact;
	}
	public void setEmergency_contact(String emergency_contact) {
		this.emergency_contact = emergency_contact;
	}
	public String getLicence_no() {
		return licence_no;
	}
	public void setLicence_no(String licence_no) {
		this.licence_no = licence_no;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getRegistration_no() {
		return registration_no;
	}
	public void setRegistration_no(String registration_no) {
		this.registration_no = registration_no;
	}
	public String getNo_plate() {
		return no_plate;
	}
	public void setNo_plate(String no_plate) {
		this.no_plate = no_plate;
	}
	
	public DriverEntity() {
		super();
	}
	

}
