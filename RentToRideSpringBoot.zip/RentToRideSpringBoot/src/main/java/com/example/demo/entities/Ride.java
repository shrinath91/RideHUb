//package com.example.demo.entities;
//
//import java.sql.Date;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.Table;
//
//@Entity
//@Table(name = "rides")
//
//public class Ride {
//	
//	@Column
//	private int rideId;
//	
//	@Column
//	private int driver_id;
//	
//	@Column
//	private String start_location;
//	
//	@Column
//	private String end_location;
//	
//	@Column
//	private Date ride_time;
//	
//	@Column
//	private double fare;
//	
//	@Column
//	private int total_capacity;
//	
//	@Column
//	private int current_capacity;
//	
//	@Column
//	private String ride_status;
//	
//	
//
//}
