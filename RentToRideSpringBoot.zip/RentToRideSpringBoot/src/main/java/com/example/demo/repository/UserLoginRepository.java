package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.demo.entities.UserEntity;

@Repository
public interface UserLoginRepository extends JpaRepository<UserEntity, Integer> {

	@Query("Select l from UserEntity l where username=:uid and password = :pwd ")
	public  Optional<UserEntity> getLoginDetails(String uid , String pwd);
}
