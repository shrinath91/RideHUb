package com.example.demo.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.UserEntity;
import com.example.demo.repository.UserLoginRepository;



@Service
public class UserLoginService {

	@Autowired
	UserLoginRepository ulrepo;
public UserEntity getLoginDetails(String username , String password) {
		
		UserEntity loginObject;
		Optional<UserEntity> log = ulrepo.getLoginDetails(username, password);
		try {
			loginObject = log.get();
		}catch (Exception e) {
			loginObject = null;
		}
		return loginObject;
	}
	
	public UserEntity save(UserEntity le)
	{
		return ulrepo.save(le);
	}
}
