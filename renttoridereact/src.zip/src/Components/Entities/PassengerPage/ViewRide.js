import React, { useState, useEffect } from "react";
//import { Link } from 'react-router-dom';
const ViewRides = () => {
  const [rides, setRides] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/getAllRides")
      .then((response) => response.json())
      .then((data) => setRides(data))
      .catch((error) => console.error("Error fetching rides:", error));
  }, []);

  return (
    <div className="container">
      <h1 className="mt-5">All Rides</h1>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Start Location</th>
            <th>End Location</th>
            <th>Ride Time</th>
            <th>Fare</th>
            <th>Total Capacity</th>
            <th>Current Capacity</th>
            <th>Ride Status</th>
          </tr>
        </thead>
        <tbody>
          {rides.map((ride) => (
            <tr key={ride.id}>
              <td>{ride.start_location}</td>
              <td>{ride.end_location}</td>
              <td>{ride.ride_time}</td>
              <td>{ride.fare}</td>
              <td>{ride.total_capacity}</td>
              <td>{ride.current_capacity}</td>
              <td>{ride.ride_status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewRides;
