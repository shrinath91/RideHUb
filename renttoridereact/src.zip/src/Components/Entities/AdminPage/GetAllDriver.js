import React, { useState, useEffect } from "react";

const GetAllDriver = () => {
  const [drivers, setDrivers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:8080/getAllDriver`)
      .then((response) => response.json())
      .then((data) => {
        setDrivers(data);
        setLoading(false);
      })
      .catch((error) => {
        setError("Error fetching drivers. Please try again later.");
        setLoading(false);
        console.error("Error fetching drivers:", error);
      });
  }, []);

  const handleApproval = (driver_user_id) => {
    fetch(`http://localhost:8080/approveDriver/${driver_user_id}`, {
      method: 'PUT',
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Driver approved:', data);
      })
      .catch((error) => {
        console.error('Error approving driver:', error);
      });
  };

  const handleDisapproval = (driver_user_id) => {
    fetch(`http://localhost:8080/disapproveDriver/${driver_user_id}`, {
      method: 'PUT',
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Driver disapproved:', data);
      })
      .catch((error) => {
        console.error('Error disapproving driver:', error);
      });
  };

  return (
    <div className="container mt-5">
      <h1 className="mb-4">All Drivers</h1>

      {loading && <p>Loading drivers...</p>}
      {error && <p className="text-danger">{error}</p>}

      {!loading && !error && (
        <div className="row row-cols-1 row-cols-md-3 g-4">
          {drivers.map((driver) => (
            <div key={driver.driver_user_id} className="col">
              <div className="card h-100">
                <div className="card-body">
                  <h5 className="card-title">{`${driver.fname} ${driver.lname}`}</h5>
                  <p className="card-text"><strong>Address:</strong> {driver.address}</p>
                  <p className="card-text"><strong>Contact:</strong> {driver.contact}</p>
                  <p className="card-text"><strong>Email:</strong> {driver.email}</p>
                  <p className="card-text"><strong>Colour:</strong> {driver.colour}</p>
                  <p className="card-text"><strong>Emergency Contact:</strong> {driver.emergency_contact}</p>
                  <p className="card-text"><strong>Make:</strong> {driver.make}</p>
                  <p className="card-text"><strong>No Plate:</strong> {driver.no_plate}</p>
                  <p className="card-text"><strong>Model:</strong> {driver.model}</p>
                  <p className="card-text"><strong>Registration No:</strong> {driver.registration_no}</p>
                  <p className="card-text"><strong>Licence No:</strong> {driver.licence_no}</p>
                  <div className="d-flex justify-content-between mt-3">
                    <button
                      className="btn btn-success"
                      onClick={() => handleApproval(driver.driver_user_id)}
                    >
                      Approve
                    </button>
                    <button
                      className="btn btn-danger"
                      onClick={() => handleDisapproval(driver.driver_user_id)}
                    >
                      Disapprove
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default GetAllDriver;
