import React, { useState, useEffect } from "react";

const GetAllPassengers = () => {
  const [passengers, setPassengers] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:8080/getAllPassenger`)
      .then((response) => response.json())
      .then((data) => setPassengers(data))
      .catch((error) => console.error("Error fetching passengers:", error));
  }, []);

  return (
    <div className="container">
      <h1 className="mt-5">All Passengers</h1>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Rating</th>
            <th>Emergency Contact</th>
          </tr>
        </thead>
        <tbody>
          {passengers.map((passenger) => (
            <tr key={passenger.id}>
              <td>{passenger.fname}</td>
              <td>{passenger.lname}</td>
              <td>{passenger.contact}</td>
              <td>{passenger.email}</td>
              <td>{passenger.rating}</td>
              <td>{passenger.emergency_contact}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default GetAllPassengers;
