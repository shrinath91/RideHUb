import React from 'react'

function ServerErrorPage() {
  return (
    <div>Welcome to ServerErrorPage</div>
  )
}

export default ServerErrorPage