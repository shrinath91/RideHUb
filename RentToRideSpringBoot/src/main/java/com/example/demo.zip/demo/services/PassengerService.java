package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.PassengerEntity;
import com.example.demo.repository.PassengerRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class PassengerService {
	@Autowired
PassengerRepository prepo;
	
	public PassengerEntity savePassenger(PassengerEntity d) {
		return prepo.save(d);
	}
	
	public List<PassengerEntity> getAllPassenger()
	{
		return prepo.findAll();
	}
	public PassengerEntity findPassengerById(int passenger_user_id) {
        return prepo.findPassengerById(passenger_user_id);
    }
	

    public void deletePassengerById(int passenger_id) {
        prepo.deleteById(passenger_id);
    }
    
    
}
