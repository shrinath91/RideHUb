package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.RideEntitiy;

@Repository
public interface RideRepository extends JpaRepository<RideEntitiy, Integer> {
	 @Query("SELECT r FROM RideEntitiy r WHERE r.ride_driver_id.driver_user_id = :ride_driver_id")
	    List<RideEntitiy> findById(@Param("ride_driver_id") int ride_driver_id);

}
